/**
 * Canonical unit contract for every persisted value and every engineering
 * calculation. Conversions are allowed only at import/export and UI edges.
 */
const SI_UNIT_SYSTEM = Object.freeze({
  id: 'SI',
  length: 'm',
  force: 'N',
  moment: 'N.m',
  stress: 'Pa',
  modulus: 'Pa',
  unitWeight: 'N/m^3',
  massDensity: 'kg/m^3'
})

const isCanonicalSiUnitSystem = (units) => {
  if (!units || typeof units !== 'object' || Array.isArray(units)) return false
  const expectedKeys = Object.keys(SI_UNIT_SYSTEM)
  const actualKeys = Object.keys(units)
  return (
    actualKeys.length === expectedKeys.length &&
    expectedKeys.every((key) => units[key] === SI_UNIT_SYSTEM[key])
  )
}

const DISPLAY_UNIT_SYSTEM = Object.freeze({
  force: 'kN',
  moment: 'kN·m',
  lineLoad: 'kN/m',
  areaLoad: 'kN/m²',
  unitWeight: 'kN/m³',
  stress: 'MPa',
  modulus: 'GPa',
  length: 'm',
  displacement: 'mm',
  rotation: 'rad',
  factor: '',
  surfaceArea: 'm²',
  volume: 'm³',
  sectionLength: 'mm',
  area: 'cm²',
  sectionModulus: 'cm³',
  inertia: 'cm⁴',
  warping: 'cm⁶',
  massDensity: 'kg/m³',
  massPerLength: 'kg/m',
  mass: 'kg',
  coupleDensity: 'kN·m/m',
  temperature: '°C',
  temperatureDifference: 'Δ°C',
  thermalExpansion: '1/K',
  speed: 'km/h'
})

const DISPLAY_FACTORS_FROM_SI = Object.freeze({
  force: 1e-3,
  moment: 1e-3,
  lineLoad: 1e-3,
  areaLoad: 1e-3,
  unitWeight: 1e-3,
  stress: 1e-6,
  modulus: 1e-9,
  length: 1,
  displacement: 1e3,
  rotation: 1,
  factor: 1,
  surfaceArea: 1,
  volume: 1,
  sectionLength: 1e3,
  area: 1e4,
  sectionModulus: 1e6,
  inertia: 1e8,
  warping: 1e12,
  massDensity: 1,
  massPerLength: 1,
  mass: 1,
  coupleDensity: 1e-3,
  temperature: 1,
  temperatureDifference: 1,
  thermalExpansion: 1,
  speed: 3.6
})

// Exact definitions: NIST SP 811 Appendix B and footnote 24. See UNITS.md.
const US_DEFINITIONS = Object.freeze({ inch: 0.0254, foot: 0.3048, poundMass: 0.45359237, poundForce: 4.4482216152605, kip: 4448.2216152605 })
const { inch, foot, poundMass, poundForce, kip } = US_DEFINITIONS
const DISPLAY_UNIT_PROFILES = Object.freeze({
  SI: Object.freeze({ id: 'SI', name: 'SI', units: DISPLAY_UNIT_SYSTEM, factors: DISPLAY_FACTORS_FROM_SI, temperatureOffset: -273.15 }),
  US: Object.freeze({
    id: 'US',
    name: 'US Customary',
    units: Object.freeze({
      force: 'kip',
      moment: 'kip·ft',
      lineLoad: 'kip/ft',
      areaLoad: 'kip/ft²',
      unitWeight: 'lbf/ft³',
      stress: 'ksi',
      modulus: 'ksi',
      length: 'ft',
      displacement: 'in',
      surfaceArea: 'ft²',
      volume: 'ft³',
      sectionLength: 'in',
      rotation: 'rad',
      factor: '',
      area: 'in²',
      sectionModulus: 'in³',
      inertia: 'in⁴',
      warping: 'in⁶',
      massDensity: 'lbm/ft³',
      massPerLength: 'lbm/ft',
      mass: 'lbm',
      coupleDensity: 'kip·ft/ft',
      temperature: '°F',
      temperatureDifference: 'Δ°F',
      thermalExpansion: '1/°F',
      speed: 'mph'
    }),
    factors: Object.freeze({
      force: 1 / kip,
      moment: 1 / (kip * foot),
      lineLoad: foot / kip,
      areaLoad: foot ** 2 / kip,
      unitWeight: foot ** 3 / poundForce,
      stress: inch ** 2 / kip,
      modulus: inch ** 2 / kip,
      length: 1 / foot,
      displacement: 1 / inch,
      surfaceArea: 1 / foot ** 2,
      volume: 1 / foot ** 3,
      sectionLength: 1 / inch,
      rotation: 1,
      factor: 1,
      area: 1 / inch ** 2,
      sectionModulus: 1 / inch ** 3,
      inertia: 1 / inch ** 4,
      warping: 1 / inch ** 6,
      massDensity: foot ** 3 / poundMass,
      massPerLength: foot / poundMass,
      mass: 1 / poundMass,
      coupleDensity: 1 / kip,
      temperature: 9 / 5,
      temperatureDifference: 9 / 5,
      thermalExpansion: 5 / 9,
      speed: 3600 / (5280 * foot)
    }),
    temperatureOffset: 32 - 273.15 * 9 / 5
  })
})

const displayUnitProfile = (id = 'SI') => {
  if (id && typeof id === 'object' && id.units && id.factors) return id
  const profile = Object.hasOwn(DISPLAY_UNIT_PROFILES, id) ? DISPLAY_UNIT_PROFILES[id] : null
  if (!profile) throw new RangeError(`Unsupported display unit profile: ${id}`)
  return profile
}

const GROUP_UNIT_OPTIONS = Object.freeze({
  length: Object.freeze(['m', 'mm', 'cm', 'ft', 'in']),
  coordinates: Object.freeze(['m', 'mm', 'cm', 'ft', 'in']),
  section: Object.freeze(['mm', 'cm', 'm', 'in', 'ft']),
  force: Object.freeze(['N', 'kN', 'lbf', 'kip']),
  stress: Object.freeze(['Pa', 'MPa', 'GPa', 'psi', 'ksi'])
})
const GROUP_UNIT_PRESETS = Object.freeze({
  SI: Object.freeze({ length: 'm', coordinates: 'm', section: 'mm', force: 'kN', stress: 'MPa' }),
  US: Object.freeze({ length: 'ft', coordinates: 'ft', section: 'in', force: 'kip', stress: 'ksi' })
})
const LENGTH_METRES = Object.freeze({ m: 1, mm: 1e-3, cm: 1e-2, ft: foot, in: inch })
const FORCE_NEWTONS = Object.freeze({ N: 1, kN: 1e3, lbf: poundForce, kip })
const STRESS_PASCALS = Object.freeze({ Pa: 1, MPa: 1e6, GPa: 1e9, psi: poundForce / inch ** 2, ksi: kip / inch ** 2 })

// Optional keys do not change the five-key Scaffolding preference contract.
const OPTIONAL_GROUP_UNIT_OPTIONS = Object.freeze({
  moment: Object.freeze(['N·m', 'N·mm', 'kN·m', 'kN·mm', 'lbf·ft', 'lbf·in', 'kip·ft', 'kip·in']),
  area: Object.freeze(['m²', 'mm²', 'cm²', 'ft²', 'in²']),
  volume: Object.freeze(['m³', 'mm³', 'cm³', 'ft³', 'in³'])
})
const MOMENT_NEWTON_METRES = Object.freeze({
  'N·m': 1, 'N·mm': 1e-3, 'kN·m': 1e3, 'kN·mm': 1,
  'lbf·ft': poundForce * foot, 'lbf·in': poundForce * inch,
  'kip·ft': kip * foot, 'kip·in': kip * inch
})
const powerUnits = (power) => Object.freeze(Object.fromEntries(Object.entries(LENGTH_METRES)
  .map(([unit, metres]) => [`${unit}${{ 2: '²', 3: '³', 4: '⁴', 6: '⁶' }[power]}`, metres ** power])))
const AREA_SQUARE_METRES = powerUnits(2)
const VOLUME_CUBIC_METRES = powerUnits(3)

/** One explicit presentation unit per role; every conversion still crosses SI. */
const createGroupedDisplayUnits = (profileId = 'SI', selected = GROUP_UNIT_PRESETS[profileId]) => {
  const base = displayUnitProfile(profileId)
  if (!selected || Object.keys(GROUP_UNIT_OPTIONS).some((role) =>
    !GROUP_UNIT_OPTIONS[role].includes(selected[role])) || Object.keys(selected).some((role) =>
    !Object.hasOwn(GROUP_UNIT_OPTIONS, role) && (!Object.hasOwn(OPTIONAL_GROUP_UNIT_OPTIONS, role) ||
      !OPTIONAL_GROUP_UNIT_OPTIONS[role].includes(selected[role])))) throw new RangeError('Unsupported display unit group')
  const length = LENGTH_METRES[selected.length]
  const section = LENGTH_METRES[selected.section]
  const coordinate = LENGTH_METRES[selected.coordinates]
  const force = FORCE_NEWTONS[selected.force]
  const stress = STRESS_PASCALS[selected.stress]
  const profile = Object.freeze({
    ...base,
    units: Object.freeze({
      ...base.units,
      length: selected.length,
      coordinate: selected.coordinates,
      sectionLength: selected.section,
      displacement: selected.section,
      surfaceArea: `${selected.length}²`,
      volume: `${selected.length}³`,
      area: `${selected.section}²`,
      sectionModulus: `${selected.section}³`,
      inertia: `${selected.section}⁴`,
      warping: `${selected.section}⁶`,
      force: selected.force,
      moment: selected.moment || `${selected.force}·${selected.length}`,
      lineLoad: `${selected.force}/${selected.length}`,
      areaLoad: `${selected.force}/${selected.length}²`,
      unitWeight: `${selected.force}/${selected.length}³`,
      coupleDensity: selected.force,
      stress: selected.stress,
      modulus: selected.stress,
      ...(selected.area ? { area: selected.area } : {}),
      ...(selected.volume ? { volume: selected.volume } : {}),
      pointStiffness: `${selected.force}/${selected.length}`,
      surfaceStiffness: `${selected.force}/${selected.length}³`,
      compliance: `${selected.length}/${selected.force}`,
      forcePerLength: `${selected.force}/${selected.length}`,
      shellMembrane: `${selected.force}/${selected.length}`,
      shellShear: `${selected.force}/${selected.length}`,
      shellBending: selected.force
    }),
    factors: Object.freeze({
      ...base.factors,
      length: 1 / length,
      coordinate: 1 / coordinate,
      sectionLength: 1 / section,
      displacement: 1 / section,
      surfaceArea: 1 / length ** 2,
      volume: 1 / length ** 3,
      area: 1 / section ** 2,
      sectionModulus: 1 / section ** 3,
      inertia: 1 / section ** 4,
      warping: 1 / section ** 6,
      force: 1 / force,
      moment: 1 / (selected.moment ? MOMENT_NEWTON_METRES[selected.moment] : force * length),
      lineLoad: length / force,
      areaLoad: length ** 2 / force,
      unitWeight: length ** 3 / force,
      coupleDensity: 1 / force,
      stress: 1 / stress,
      modulus: 1 / stress,
      ...(selected.area ? { area: 1 / AREA_SQUARE_METRES[selected.area] } : {}),
      ...(selected.volume ? { volume: 1 / VOLUME_CUBIC_METRES[selected.volume] } : {}),
      pointStiffness: length / force,
      surfaceStiffness: length ** 3 / force,
      compliance: force / length,
      forcePerLength: length / force,
      shellMembrane: length / force,
      shellShear: length / force,
      shellBending: 1 / force
    }),
    groups: Object.freeze({ ...selected })
  })
  return Object.freeze({
    ...profile,
    fromSi: (quantity, value) => fromSiForDisplay(quantity, value, profile),
    toSi: (quantity, value) => toSiFromDisplay(quantity, value, profile),
    format: (quantity, value, options = {}) => formatSiForDisplay(quantity, value, { ...options, profileId: profile }),
    input: (quantity, value) => inputSiForDisplay(quantity, value, profile)
  })
}

const fromSiForDisplay = (quantity, value, profileId = 'SI') => {
  const profile = displayUnitProfile(profileId)
  const factor = profile.factors[quantity]
  const number = Number(value)
  if (value == null || value === '' || !Number.isFinite(number) || factor == null) return null
  const result = number * factor + (quantity === 'temperature' ? profile.temperatureOffset : 0)
  return Number.isFinite(result) ? result : null
}

const toSiFromDisplay = (quantity, value, profileId = 'SI') => {
  const profile = displayUnitProfile(profileId)
  const factor = profile.factors[quantity]
  const number = Number(value)
  if (value == null || value === '' || !Number.isFinite(number) || factor == null || factor === 0) return null
  const result = (number - (quantity === 'temperature' ? profile.temperatureOffset : 0)) / factor
  return Number.isFinite(result) ? result : null
}

/** Absolute temperature is persisted in kelvin; the UI and MCT use Celsius. */
const temperatureKToCelsius = (value) => {
  const number = Number(value)
  return Number.isFinite(number) ? number - 273.15 : null
}

const temperatureCelsiusToK = (value) => {
  const number = Number(value)
  return Number.isFinite(number) ? number + 273.15 : null
}

/**
 * Adaptive engineering notation for a value already converted to display
 * units. Small non-zero values are never rounded to a misleading zero.
 */
const formatDisplayNumber = (value, options = {}) => {
  const number = Number(value)
  if (value == null || value === '' || !Number.isFinite(number)) return options.fallback || '—'
  if (number === 0) return '0'
  const magnitude = Math.abs(number)
  if (magnitude >= 1000) return number.toPrecision(options.significant || 5)
  if (magnitude >= 100) return number.toFixed(1)
  if (magnitude >= 1) return number.toFixed(3)
  if (magnitude >= 1e-3) return number.toFixed(5)
  return number.toExponential(3)
}

const formatSiForDisplay = (quantity, value, options = {}) => {
  const profileId = options.profileId || 'SI'
  const converted = fromSiForDisplay(quantity, value, profileId)
  const formatted = formatDisplayNumber(converted, options)
  if (!options.withUnit || formatted === (options.fallback || '—')) return formatted
  const unit = displayUnitProfile(profileId).units[quantity]
  return unit ? `${formatted} ${unit}` : formatted
}

/** Shorten editable numbers only when parsing them preserves the exact SI value. */
const inputSiForDisplay = (quantity, value, profileId) => {
  const converted = fromSiForDisplay(quantity, value, profileId)
  if (converted === null) return ''
  const si = Number(value)
  const rawLength = String(converted).length
  // Binary64 needs at most 17 significant decimal digits. No tolerance or
  // fixed decimal cutoff is allowed: e.g. 15.000000000000002 must stay distinct.
  for (let digits = 1; digits <= 17; digits++) {
    const candidate = Number(converted.toPrecision(digits))
    if (String(candidate).length < rawLength && toSiFromDisplay(quantity, candidate, profileId) === si) return candidate
  }
  return converted
}

const createDisplayUnits = (profileId = 'SI') => {
  const profile = displayUnitProfile(profileId)
  return Object.freeze({
    ...profile,
    fromSi: (quantity, value) => fromSiForDisplay(quantity, value, profileId),
    toSi: (quantity, value) => toSiFromDisplay(quantity, value, profileId),
    format: (quantity, value, options = {}) => formatSiForDisplay(quantity, value, { ...options, profileId }),
    input: (quantity, value) => inputSiForDisplay(quantity, value, profileId)
  })
}

const compoundUnits = (lengthPower, inverse = false) => {
  const suffix = lengthPower === 1 ? '' : '³'
  return Object.freeze(Object.fromEntries(Object.entries(FORCE_NEWTONS).flatMap(([forceUnit, newtons]) =>
    Object.entries(LENGTH_METRES).map(([lengthUnit, metres]) => inverse
      ? [`${lengthUnit}/${forceUnit}`, metres / newtons]
      : [`${forceUnit}/${lengthUnit}${suffix}`, newtons / metres ** lengthPower]))))
}
const POINT_STIFFNESS = compoundUnits(1)
const UNIT_SCALES_TO_SI = Object.freeze({
  length: LENGTH_METRES, coordinate: LENGTH_METRES, sectionLength: LENGTH_METRES, displacement: LENGTH_METRES,
  force: FORCE_NEWTONS, moment: MOMENT_NEWTON_METRES, stress: STRESS_PASCALS, modulus: STRESS_PASCALS,
  area: AREA_SQUARE_METRES, surfaceArea: AREA_SQUARE_METRES, volume: VOLUME_CUBIC_METRES,
  sectionModulus: VOLUME_CUBIC_METRES, inertia: powerUnits(4), warping: powerUnits(6),
  pointStiffness: POINT_STIFFNESS, forcePerLength: POINT_STIFFNESS, lineLoad: POINT_STIFFNESS,
  shellMembrane: POINT_STIFFNESS, shellShear: POINT_STIFFNESS,
  surfaceStiffness: compoundUnits(3), compliance: compoundUnits(1, true),
  shellBending: FORCE_NEWTONS, rotation: Object.freeze({ rad: 1 }),
  factor: Object.freeze({ '': 1 }), angleDeg: Object.freeze({ '°': 1, deg: 1 })
})
const CANONICAL_QUANTITY_UNITS = Object.freeze({
  length: 'm', coordinate: 'm', sectionLength: 'm', displacement: 'm', force: 'N', moment: 'N·m',
  stress: 'Pa', modulus: 'Pa', area: 'm²', surfaceArea: 'm²', volume: 'm³', sectionModulus: 'm³',
  inertia: 'm⁴', warping: 'm⁶', pointStiffness: 'N/m', forcePerLength: 'N/m', lineLoad: 'N/m',
  shellMembrane: 'N/m', shellShear: 'N/m', surfaceStiffness: 'N/m³', compliance: 'm/N',
  shellBending: 'N', rotation: 'rad', factor: '', angleDeg: 'deg'
})
// Declared machine-contract aliases only, never a unit parser or a persistence repair.
const UNIT_ALIASES = Object.freeze({
  moment: Object.freeze({ 'N*m': 'N·m', 'N.m': 'N·m', 'N*mm': 'N·mm' }),
  area: Object.freeze({ m2: 'm²', mm2: 'mm²' }),
  inertia: Object.freeze({ m4: 'm⁴', mm4: 'mm⁴' }),
  surfaceStiffness: Object.freeze({ 'N/m3': 'N/m³', 'N/mm3': 'N/mm³' })
})
class UnitConversionError extends RangeError {
  constructor (code, message) { super(message); this.name = 'UnitConversionError'; this.code = code }
}
const convertQuantity = (quantity, value, sourceUnit, targetUnit = CANONICAL_QUANTITY_UNITS[quantity]) => {
  if (!Object.hasOwn(UNIT_SCALES_TO_SI, quantity)) throw new UnitConversionError('E-UNIT-QUANTITY', `Unsupported quantity: ${quantity}`)
  const scales = UNIT_SCALES_TO_SI[quantity]
  const unit = (label) => UNIT_ALIASES[quantity]?.[label] || label
  if (!Object.hasOwn(scales, unit(sourceUnit)) || !Object.hasOwn(scales, unit(targetUnit))) {
    throw new UnitConversionError('E-UNIT-SYMBOL', `Unsupported ${quantity} unit: ${sourceUnit} -> ${targetUnit}`)
  }
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new UnitConversionError('E-UNIT-NONFINITE', 'Conversion requires a finite number')
  const ratio = scales[unit(sourceUnit)] / scales[unit(targetUnit)]
  const converted = value * ratio
  if (!Number.isFinite(converted) || (value !== 0 && converted === 0)) throw new UnitConversionError('E-UNIT-REPRESENTATION', 'Conversion overflow or nonzero underflow')
  return converted
}

module.exports = {
  SI_UNIT_SYSTEM,
  isCanonicalSiUnitSystem,
  DISPLAY_UNIT_SYSTEM,
  DISPLAY_FACTORS_FROM_SI,
  DISPLAY_UNIT_PROFILES,
  GROUP_UNIT_OPTIONS,
  GROUP_UNIT_PRESETS,
  OPTIONAL_GROUP_UNIT_OPTIONS,
  CANONICAL_QUANTITY_UNITS,
  UNIT_SCALES_TO_SI,
  UnitConversionError,
  convertQuantity,
  US_DEFINITIONS,
  displayUnitProfile,
  createDisplayUnits,
  createGroupedDisplayUnits,
  fromSiForDisplay,
  toSiFromDisplay,
  temperatureKToCelsius,
  temperatureCelsiusToK,
  formatDisplayNumber,
  formatSiForDisplay
}

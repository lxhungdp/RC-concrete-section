# `@jscad/engineering-units`

Pure shared unit definitions, SI/display conversion contexts and editable-number formatting.
The [unit contract](../../docs/engineering/basis/UNITS.md) owns quantities and source-backed
definitions. This package has no model, solver, code equations, DOM, I/O or storage dependency.

The CommonJS and ESM public roots expose the same objects/functions. TypeScript declarations
describe quantities, immutable contexts and typed conversion failures. `@jscad/structure/units`
remains a compatibility facade; its existing profile/group selections and conversions retain
their behavior. The five required group keys stay unchanged so existing version-2 preferences
retain their interpretation. Optional moment, area and volume groups are independent overrides.

`createGroupedDisplayUnits(profileId, groups)` creates an immutable context. Products own their
default group selections and store presentation preferences outside engineering models.
Point/surface stiffness, compliance and shell-resultant roles have explicit dimensional mappings;
sharing dimensions does not erase their distinct quantity names. `convertQuantity` validates
the quantity, explicit source/target units and finite representability. Unknown units/roles fail
with `UnitConversionError`; no substring or magnitude inference is used. Legacy nullable
display helpers retain their documented refusal behavior.

Anchor consumes an exact versioned npm artifact generated from this source, with a bound source
digest and lockfile integrity. Run `node scripts/prepare-anchor-units.cjs` from the repository
root before its isolated install. This does not make Anchor a root workspace or permit imports
of Structures calculation packages.

```text
npm test -w @jscad/engineering-units
npm test -w @jscad/structure
```

export type ProfileId = 'SI' | 'US'
export type ConvertibleQuantity = 'length' | 'coordinate' | 'sectionLength' | 'displacement' |
  'force' | 'moment' | 'stress' | 'modulus' | 'area' | 'surfaceArea' | 'volume' | 'sectionModulus' |
  'inertia' | 'warping' | 'pointStiffness' | 'forcePerLength' | 'lineLoad' | 'shellMembrane' |
  'shellShear' | 'surfaceStiffness' | 'compliance' | 'shellBending' | 'rotation' | 'factor' | 'angleDeg'
export type DisplayQuantity = ConvertibleQuantity | 'areaLoad' | 'unitWeight' | 'massDensity' |
  'massPerLength' | 'mass' | 'coupleDensity' | 'temperature' | 'temperatureDifference' | 'thermalExpansion' | 'speed'
export type GroupId = 'length' | 'coordinates' | 'section' | 'force' | 'stress'
export type OptionalGroupId = 'moment' | 'area' | 'volume'
export type GroupSelection = Readonly<Record<GroupId, string> & Partial<Record<OptionalGroupId, string>>>
export interface CanonicalUnits {
  readonly id: 'SI'; readonly length: 'm'; readonly force: 'N'; readonly moment: 'N.m';
  readonly stress: 'Pa'; readonly modulus: 'Pa'; readonly unitWeight: 'N/m^3'; readonly massDensity: 'kg/m^3'
}
export interface DisplayProfile {
  readonly id: ProfileId; readonly name: string;
  readonly units: Readonly<Partial<Record<DisplayQuantity, string>>>;
  readonly factors: Readonly<Partial<Record<DisplayQuantity, number>>>;
  readonly temperatureOffset: number;
  readonly groups?: GroupSelection;
}
export interface FormatOptions { fallback?: string; significant?: number; withUnit?: boolean; profileId?: ProfileId | DisplayProfile }
export interface DisplayContext extends DisplayProfile {
  fromSi(quantity: DisplayQuantity, value: unknown): number | null;
  toSi(quantity: DisplayQuantity, value: unknown): number | null;
  format(quantity: DisplayQuantity, value: unknown, options?: FormatOptions): string;
  input(quantity: DisplayQuantity, value: unknown): number | '';
}
export const SI_UNIT_SYSTEM: CanonicalUnits
export function isCanonicalSiUnitSystem(units: unknown): units is CanonicalUnits
export const DISPLAY_UNIT_SYSTEM: DisplayProfile['units']
export const DISPLAY_FACTORS_FROM_SI: DisplayProfile['factors']
export const DISPLAY_UNIT_PROFILES: Readonly<Record<ProfileId, DisplayProfile>>
export const GROUP_UNIT_OPTIONS: Readonly<Record<GroupId, readonly string[]>>
export const GROUP_UNIT_PRESETS: Readonly<Record<ProfileId, GroupSelection>>
export const OPTIONAL_GROUP_UNIT_OPTIONS: Readonly<Record<OptionalGroupId, readonly string[]>>
export const CANONICAL_QUANTITY_UNITS: Readonly<Record<ConvertibleQuantity, string>>
export const UNIT_SCALES_TO_SI: Readonly<Record<ConvertibleQuantity, Readonly<Record<string, number>>>>
export const US_DEFINITIONS: Readonly<{ inch: number; foot: number; poundMass: number; poundForce: number; kip: number }>
export class UnitConversionError extends RangeError {
  readonly code: 'E-UNIT-QUANTITY' | 'E-UNIT-SYMBOL' | 'E-UNIT-NONFINITE' | 'E-UNIT-REPRESENTATION'
  constructor(code: UnitConversionError['code'], message: string)
}
export function convertQuantity(quantity: ConvertibleQuantity, value: number, sourceUnit: string, targetUnit?: string): number
export function displayUnitProfile(id?: ProfileId | DisplayProfile): DisplayProfile
export function createDisplayUnits(id?: ProfileId | DisplayProfile): DisplayContext
export function createGroupedDisplayUnits(id?: ProfileId, groups?: GroupSelection): DisplayContext
export function fromSiForDisplay(quantity: DisplayQuantity, value: unknown, id?: ProfileId | DisplayProfile): number | null
export function toSiFromDisplay(quantity: DisplayQuantity, value: unknown, id?: ProfileId | DisplayProfile): number | null
export function temperatureKToCelsius(value: unknown): number | null
export function temperatureCelsiusToK(value: unknown): number | null
export function formatDisplayNumber(value: unknown, options?: FormatOptions): string
export function formatSiForDisplay(quantity: DisplayQuantity, value: unknown, options?: FormatOptions): string
